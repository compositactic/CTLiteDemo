Northwind Demo Domain Model
Root directory is NorthwindApplications