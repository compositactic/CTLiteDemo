﻿CTLite CTGen Quick Start

* Generate the Northwind Solution:

	* The Quick Start Batch script will generate the Northwind Solution with all Projects, a ASP.NET Core API application, and database on MS SQL Server LocalDB 
	* From a command-line window in this directory:
	
	quickstart.bat

* 
